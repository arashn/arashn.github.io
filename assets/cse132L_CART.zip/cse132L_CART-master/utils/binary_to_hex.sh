#!/bin/bash
while IFS='' read -r line || [[ -n "$line" ]]; do
	echo "ibase=2;obase=10000;$line"|bc >> $2
done < "$1"
